// File: src/app/(main)/folder/styles.ts
import { StyleSheet } from 'react-native';

export const folderStyles = StyleSheet.create({
  root: { flex: 1 },
  actionStrip: { flexDirection: 'row', justifyContent: 'space-around', paddingHorizontal: 16, marginVertical: 8, paddingVertical: 4 },
  shredButton: { backgroundColor: '#FF3B30', paddingVertical: 6, paddingHorizontal: 12, borderRadius: 16 },
  dangerPill: { paddingVertical: 6, paddingHorizontal: 12, borderRadius: 16 },
  selectPill: { paddingVertical: 6, paddingHorizontal: 12, borderRadius: 16 },
  actionPill: { paddingVertical: 6, paddingHorizontal: 12, borderRadius: 16 },
  selectionCount: { fontSize: 14 },
  fileCard: { marginVertical: 6, borderRadius: 20, padding: 12 },
  folderCard: { marginVertical: 6, borderRadius: 20, padding: 12 },
  folderRow: { flexDirection: 'row', alignItems: 'center' },
  folderIcon: { fontSize: 24 },
  fileName: { fontSize: 15, fontWeight: '600', paddingRight: 8 },
  deleteFileIcon: { padding: 4 },
  menuButton: { padding: 4, marginLeft: 4 },
  empty: { textAlign: 'center', marginTop: 40 },
  sectionLabel: { fontSize: 12, fontWeight: '600', marginBottom: 8, paddingHorizontal: 16, letterSpacing: 0.5, textTransform: 'uppercase' },
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  flexRow: { flexDirection: 'row', alignItems: 'center' },
  flexOne: { flex: 1 },
  marginLeft12: { marginLeft: 12 },
  marginRight12: { marginRight: 12 },
  marginRight8: { marginRight: 8 },
  paddingTopBottom8: { paddingTop: 8, paddingBottom: 8 },
  marginLeft8: { marginLeft: 8 },
  menuOverlay: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.7)' },
  menuPopup: { width: '85%', borderRadius: 20, padding: 20 },
  menuTitle: { color: '#FFF', fontSize: 18, fontWeight: 'bold', marginBottom: 12 },
  menuItem: { paddingVertical: 16, borderBottomWidth: 1, borderBottomColor: '#2D2D44' },
  modalOverlay: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.7)' },
  modalContent: { width: '85%', padding: 20, borderRadius: 20, alignItems: 'center' },
  textInput: { borderWidth: 2, borderRadius: 16, padding: 12, width: '100%', marginBottom: 16 },
  modalButtons: { flexDirection: 'row', justifyContent: 'space-between', width: '100%' },
  moveOption: { paddingVertical: 16 },
  bottomTabs: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 70,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.1)',
    backgroundColor: 'rgba(26,26,46,0.9)'
  },
  tabButton: { alignItems: 'center', padding: 8 },
  padding16: { padding: 16 },
  headerBtn: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12 },
  headerIconBtn: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,0.08)' },

  // Stats Banner - Full-width card with 24px border radius
  statsBanner: {
    flexDirection: 'row',
    marginHorizontal: 16,
    marginTop: 8,
    marginBottom: 4,
    borderRadius: 24,
    paddingVertical: 16,
    paddingHorizontal: 4,
  },
  statItem: { flex: 1, alignItems: 'center' },
  statNum: { fontSize: 18, fontWeight: '800' },
  statLabel: { fontSize: 11, fontWeight: '600', marginTop: 4 },
  statDivider: { width: 1, marginVertical: 4, backgroundColor: '#222225' },

  // Action Strip - Pill buttons with 999 border radius
  actionStripLocal: { flexDirection: 'row', gap: 8, paddingHorizontal: 16, paddingVertical: 10, alignItems: 'center' },
  primaryChip: { paddingHorizontal: 20, paddingVertical: 12, borderRadius: 999 },
  actionChip: { paddingHorizontal: 16, paddingVertical: 12, borderRadius: 999 },
  selCountBadge: { paddingHorizontal: 14, paddingVertical: 12, borderRadius: 999 },

  scrollContent: { paddingHorizontal: 16, paddingTop: 4 },

  // Section Labels - Uppercase, small, generous letter spacing
  sectionLabelLocal: { fontSize: 11, fontWeight: '700', letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 10, marginTop: 4 },

  // Folder Cards - 20px border radius, no borders
  folderCardLocal: { marginBottom: 8, borderRadius: 20, overflow: 'hidden' },
  folderCardRow: { flexDirection: 'row', alignItems: 'center', padding: 14 },

  // Folder Icon Box - Darker rounded square wrapper
  folderIconBox: { width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },

  // File Cards - 20px border radius, no borders
  fileCardLocal: { marginBottom: 8, borderRadius: 20, overflow: 'hidden' },
  fileCardRow: { flexDirection: 'row', alignItems: 'center', padding: 14 },

  // File Icon Box - Darker rounded square wrapper
  fileIconBox: { width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center', position: 'relative' },

  encryptedBadge: { position: 'absolute', bottom: -2, right: -2, backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: 6, padding: 2 },

  fileNameLocal: { fontSize: 15, fontWeight: '700' },

  checkCircle: { width: 22, height: 22, borderRadius: 11, borderWidth: 2, alignItems: 'center', justifyContent: 'center' },

  fileActionBtn: { width: 34, height: 34, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },

  emptyBlock: { alignItems: 'center', paddingVertical: 52 },
  progressCard: { margin: 40, borderRadius: 24, padding: 32, alignItems: 'center' },
  progressText: { fontSize: 15, fontWeight: '600', marginTop: 16, marginBottom: 16 },
  progressBar: { width: '100%', height: 6, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.1)', overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 3 },

  bottomTabsLocal: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 76,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    backgroundColor: 'rgba(13,13,20,0.92)',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.08)',
  },
  tabButtonLocal: { alignItems: 'center', justifyContent: 'center', paddingHorizontal: 16 },
  tabLabel: { fontSize: 10, marginTop: 3, fontWeight: '600' },
});

export const sheetStyles = StyleSheet.create({
  overlay: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.65)' },
  sheet: { borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingTop: 12, paddingBottom: 44 },
  handle: { width: 40, height: 4, borderRadius: 2, backgroundColor: 'rgba(255,255,255,0.2)', alignSelf: 'center', marginBottom: 8 },
  sheetTitle: { fontSize: 18, fontWeight: '800', paddingHorizontal: 24, paddingVertical: 12 },
  item: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 24, paddingVertical: 15, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.05)' },
  itemIcon: { fontSize: 20, marginRight: 16, width: 28 },
  itemLabel: { fontSize: 16, fontWeight: '500' },
  input: { borderWidth: 1.5, borderRadius: 16, paddingHorizontal: 16, paddingVertical: 14, marginHorizontal: 24, marginBottom: 20, fontSize: 16 },
  btnRow: { flexDirection: 'row', gap: 12, paddingHorizontal: 24 },
  cancelBtn: { flex: 1, paddingVertical: 14, borderRadius: 16, alignItems: 'center', borderWidth: 1.5 },
  confirmBtn: { flex: 1, paddingVertical: 14, borderRadius: 16, alignItems: 'center' },
});
