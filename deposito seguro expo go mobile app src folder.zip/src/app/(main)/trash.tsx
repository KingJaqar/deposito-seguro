// File: src/app/(main)/trash.tsx
import { Moon, Search, Sun } from 'lucide-react-native';
import { useCallback, useMemo, useState } from 'react';
import {
  Alert,
  Dimensions,
  FlatList,
  Modal,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import AnimatedTabBar from '../../components/AnimatedTabBar';
import { useTheme } from '../../contexts/ThemeContext';
import { useVaultStore } from '../../store/vaultStore';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const SCREEN_PADDING = 20;
const VAULT_GAP = 12;
const TRASH_TILE_WIDTH = (SCREEN_WIDTH - SCREEN_PADDING * 2 - VAULT_GAP) / 2;

type SortKey = 'date_desc' | 'date_asc' | 'name_asc' | 'name_desc';
type FileTypeFilter = 'all' | 'image' | 'video' | 'document' | 'audio' | 'other';

interface TrashedFile {
  id: string;
  name: string;
  isTrash: boolean;
  folderId?: string | null;
  type?: string;
  size?: number;
  deletedAt?: string;
  [key: string]: any;
}

const CATEGORY_FILTERS = [
  { label: 'All', tint: '#A78BFA' },
  { label: 'Images', tint: '#34D399' },
  { label: 'Videos', tint: '#FF6B6B' },
  { label: 'Documents', tint: '#60A5FA' },
  { label: 'Audio', tint: '#FBBF24' },
  { label: 'Other', tint: '#94A3B8' },
];

const FILE_TYPE_MAP: Record<FileTypeFilter, string> = {
  all: 'All',
  image: 'Images',
  video: 'Videos',
  document: 'Documents',
  audio: 'Audio',
  other: 'Other',
};

function detectType(name: string): FileTypeFilter {
  const ext = name.split('.').pop()?.toLowerCase() ?? '';
  if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'heic', 'svg'].includes(ext)) return 'image';
  if (['mp4', 'mov', 'avi', 'mkv', 'webm'].includes(ext)) return 'video';
  if (['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'md'].includes(ext)) return 'document';
  if (['mp3', 'wav', 'aac', 'ogg', 'flac'].includes(ext)) return 'audio';
  return 'other';
}

function formatFileSize(bytes?: number): string {
  if (!bytes) return '';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function formatDeletedAt(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleString(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function groupByDate(files: TrashedFile[]): { label: string; data: TrashedFile[] }[] {
  const groups: Record<string, TrashedFile[]> = {};
  const now = new Date();

  files.forEach(f => {
    const d = new Date(f.deletedAt!);
    const diffDays = Math.floor((now.getTime() - d.getTime()) / 86_400_000);

    let label: string;
    if (diffDays === 0) label = 'Today';
    else if (diffDays === 1) label = 'Yesterday';
    else if (diffDays < 7) label = 'This Week';
    else if (diffDays < 30) label = 'This Month';
    else label = 'Older';

    if (!groups[label]) groups[label] = [];
    groups[label].push(f);
  });

  const ORDER = ['Today', 'Yesterday', 'This Week', 'This Month', 'Older'];
  return ORDER.filter(l => groups[l]).map(l => ({ label: l, data: groups[l] }));
}

function getFileType(mimeType: string, name?: string) {
  if (mimeType?.startsWith('image/')) return { label: 'Image', color: '#A78BFA', icon: '🖼' };
  if (mimeType?.startsWith('video/')) return { label: 'Video', color: '#FF6B6B', icon: '▶' };
  if (mimeType?.startsWith('audio/')) return { label: 'Audio', color: '#FBBF24', icon: '♪' };
  if (name?.endsWith('.apk') || name?.endsWith('.exe')) return { label: 'App', color: '#F472B6', icon: '📱' };
  return { label: 'File', color: '#60A5FA', icon: '📄' };
}

export default function TrashScreen() {
  const { colors, isDark, toggleTheme } = useTheme();
  const { files, restoreFileFromTrash, permanentlyDeleteFile, permanentlyDeleteFiles } = useVaultStore();

  const dash = {
    bg: colors.dashboardBg ?? colors.background,
    surface: colors.dashboardSurface ?? colors.surface,
    surfaceHover: colors.dashboardSurfaceHover ?? colors.surfaceElevated,
    accent: colors.dashboardAccent ?? colors.accent,
    text: colors.dashboardText ?? colors.text,
    textMuted: colors.dashboardTextMuted ?? colors.textMuted,
    border: colors.dashboardBorder ?? colors.border,
    fabBg: colors.fabBg ?? colors.primary,
    fabText: colors.fabText ?? '#FFFFFF',
  };

  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<FileTypeFilter>('all');
  const [sort, setSort] = useState<SortKey>('date_desc');
  const [showFilters, setShowFilters] = useState(false);
  const [showFileMenu, setShowFileMenu] = useState(false);
  const [targetItem, setTargetItem] = useState<any>(null);
  const [selectionMode, setSelectionMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const enrichedFiles: TrashedFile[] = useMemo(() => {
    return (files as TrashedFile[])
      .filter(f => f.isTrash)
      .map(f => ({
        ...f,
        deletedAt: f.deletedAt ?? new Date(0).toISOString(),
      }));
  }, [files]);

  const filtered = useMemo(() => {
    let result = enrichedFiles;

    if (search.trim()) {
      const q = search.trim().toLowerCase();
      result = result.filter(f => f.name.toLowerCase().includes(q));
    }

    if (typeFilter !== 'all') {
      result = result.filter(f => detectType(f.name) === typeFilter);
    }

    result = [...result].sort((a, b) => {
      switch (sort) {
        case 'date_desc': return new Date(b.deletedAt!).getTime() - new Date(a.deletedAt!).getTime();
        case 'date_asc': return new Date(a.deletedAt!).getTime() - new Date(b.deletedAt!).getTime();
        case 'name_asc': return a.name.localeCompare(b.name);
        case 'name_desc': return b.name.localeCompare(a.name);
      }
    });

    return result;
  }, [enrichedFiles, search, typeFilter, sort]);

  const grouped = useMemo(() => groupByDate(filtered), [filtered]);

  const handleShred = useCallback((id: string, name: string) => {
    Alert.alert('Permanently Shred File', `"${name}" will be destroyed forever.`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Shred', style: 'destructive', onPress: () => permanentlyDeleteFile(id) },
    ]);
  }, [permanentlyDeleteFile]);

  const handleShredAll = useCallback(() => {
    if (filtered.length === 0) return;
    Alert.alert('Shred All Files?', `This will permanently delete all ${filtered.length} files.`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Shred All',
        style: 'destructive',
        onPress: () => permanentlyDeleteFiles(filtered.map(f => f.id)),
      },
    ]);
  }, [filtered, permanentlyDeleteFiles]);

  const handleRestoreSelected = useCallback(() => {
    if (selectedIds.length === 0) return;
    selectedIds.forEach(id => restoreFileFromTrash(id));
    setSelectedIds([]);
    setSelectionMode(false);
  }, [selectedIds, restoreFileFromTrash]);

  const handleShredSelected = useCallback(() => {
    if (selectedIds.length === 0) return;
    Alert.alert('Shred Selected Files?', `This will permanently delete ${selectedIds.length} files.`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Shred',
        style: 'destructive',
        onPress: () => permanentlyDeleteFiles(selectedIds),
      },
    ]);
  }, [selectedIds, permanentlyDeleteFiles]);

  const toggleSelection = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const exitSelectionMode = () => { setSelectionMode(false); setSelectedIds([]); };

  const toggleFilters = () => {
    setShowFilters(!showFilters);
  };

  const TrashTile = ({ item, index }: { item: TrashedFile; index: number }) => {
    const ft = getFileType(item.type || '', item.name);
    const accentColor = ['#A78BFA', '#60A5FA', '#34D399', '#FB7185', '#FBBF24', '#F472B6'][index % 6];
    const isSelected = selectedIds.includes(item.id);

    return (
      <TouchableOpacity
        onLongPress={() => { setSelectionMode(true); setSelectedIds([item.id]); }}
        onPress={() => {
          if (selectionMode) toggleSelection(item.id);
        }}
        style={[
          styles.vaultTile,
          {
            backgroundColor: dash.surface,
            width: TRASH_TILE_WIDTH,
            borderColor: isSelected ? dash.accent : 'transparent',
            borderWidth: 2,
          },
        ]}
      >
        <View style={styles.vaultTopRow}>
          <View style={[styles.vaultIconChip, { backgroundColor: `${accentColor}20` }]}>
            <Text style={{ fontSize: 18 }}>{ft?.icon || '📄'}</Text>
          </View>
          {selectionMode ? (
            <View style={styles.checkBox}>
              <View style={[styles.checkInner, { backgroundColor: isSelected ? dash.accent : 'transparent', borderColor: dash.accent }]}>
                {isSelected && <Text style={{ color: dash.fabText, fontSize: 10, fontWeight: '700' }}>✓</Text>}
              </View>
            </View>
          ) : (
            <TouchableOpacity
              onPress={() => { setTargetItem(item); setShowFileMenu(true); }}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
              activeOpacity={0.7}
            >
              <Text style={{ color: dash.textMuted, fontSize: 18, fontWeight: '600' }}>•••</Text>
            </TouchableOpacity>
          )}
        </View>

        <View style={styles.vaultBottomBlock}>
          <Text style={[styles.vaultName, { color: dash.text }]} numberOfLines={1}>
            {item.name}
          </Text>
          <View style={styles.vaultMetaRow}>
            <Text style={[styles.vaultMeta, { color: dash.textMuted, fontSize: 11 }]}>
              {formatDeletedAt(item.deletedAt!)}
            </Text>
            <Text style={[styles.vaultMeta, { color: ft.color, fontSize: 11 }]}>{ft.label}</Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  type ListItem =
    | { type: 'section'; label: string }
    | { type: 'file'; file: TrashedFile };

  const listData: ListItem[] = useMemo(() => {
    const items: ListItem[] = [];
    grouped.forEach(g => {
      items.push({ type: 'section', label: g.label });
      g.data.forEach(f => items.push({ type: 'file', file: f }));
    });
    return items;
  }, [grouped]);

  return (
    <View style={[styles.root, { backgroundColor: dash.bg }]}>
      <SafeAreaView>
        <View style={[styles.headerRow, { backgroundColor: dash.bg }]}>
          <View style={styles.headerTextBlock}>
            <Text style={[styles.headerTitle, { color: dash.text }]} numberOfLines={1}>Trash</Text>
            <Text style={[styles.headerTagline, { color: dash.textMuted }]} numberOfLines={1}>Deleted files</Text>
          </View>
          <Pressable
            onPress={toggleTheme}
            style={[styles.themeToggle, { backgroundColor: dash.surfaceHover }]}
            accessibilityRole="button"
            accessibilityLabel={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
          >
            {isDark ? <Sun size={18} color={dash.text} /> : <Moon size={18} color={dash.text} />}
          </Pressable>
        </View>
      </SafeAreaView>

      <View style={{ flex: 1 }}>
        <ScrollView
          contentContainerStyle={styles.scrollBody}
          showsVerticalScrollIndicator={false}
        >
          <View style={[styles.searchBar, { backgroundColor: dash.surface }]}>
            <Search size={18} color={dash.textMuted} />
            <TextInput
              style={[styles.searchInput, { color: dash.text }]}
              placeholder="Search deleted files..."
              placeholderTextColor={dash.textMuted}
              value={search}
              onChangeText={setSearch}
              returnKeyType="search"
              clearButtonMode="while-editing"
            />
            {search.length > 0 && (
              <TouchableOpacity onPress={() => setSearch('')} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                <Text style={{ color: dash.textMuted, fontSize: 16 }}>✕</Text>
              </TouchableOpacity>
            )}
          </View>

          {/* Filters Row */}
          <View style={styles.filterRow}>
            <TouchableOpacity
              onPress={toggleFilters}
              style={[styles.filterToggleBtn, { backgroundColor: dash.surface, borderColor: dash.border, borderWidth: 1 }]}
            >
              <Text style={[styles.filterToggleText, { color: dash.textMuted }]}>⚙ Filters</Text>
            </TouchableOpacity>
            {!selectionMode && filtered.length > 0 && (
              <TouchableOpacity onPress={handleShredAll}>
                <Text style={[styles.shredAllText, { color: '#ff5f5f' }]}>Shred All</Text>
              </TouchableOpacity>
            )}
          </View>

          {showFilters && (
            <View style={styles.filterPanel}>
              <View style={styles.categorySection}>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.categoryScroll}>
                  {(Object.keys(FILE_TYPE_MAP) as FileTypeFilter[]).map(k => {
                    const isActive = typeFilter === k;
                    const tint = k === 'all' ? '#A78BFA' : k === 'image' ? '#34D399' : k === 'video' ? '#FF6B6B' : k === 'document' ? '#60A5FA' : k === 'audio' ? '#FBBF24' : '#94A3B8';
                    return (
                      <TouchableOpacity
                        key={k}
                        onPress={() => setTypeFilter(k)}
                        activeOpacity={0.75}
                      >
                        <View style={[
                          styles.categoryPill,
                          {
                            backgroundColor: isActive ? dash.surface : `${tint}12`,
                            borderColor: isActive ? dash.textMuted : `${tint}35`,
                            borderWidth: isActive ? 1.5 : 1,
                          },
                        ]}>
                          <View style={[styles.categoryDot, { backgroundColor: tint }]} />
                          <Text style={[
                            styles.categoryPillLabel,
                            { color: isActive ? dash.text : tint, fontWeight: isActive ? '700' : '500' }
                          ]}>
                            {FILE_TYPE_MAP[k]}
                          </Text>
                        </View>
                      </TouchableOpacity>
                    );
                  })}
                </ScrollView>
              </View>

              <View style={styles.categorySection}>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.categoryScroll}>
                  {([
                    ['date_desc', '🕐 Newest'],
                    ['date_asc', '🕐 Oldest'],
                    ['name_asc', 'A → Z'],
                    ['name_desc', 'Z → A'],
                  ] as [SortKey, string][]).map(([k, label]) => {
                    const isActive = sort === k;
                    return (
                      <TouchableOpacity
                        key={k}
                        onPress={() => setSort(k)}
                        activeOpacity={0.75}
                      >
                        <View style={[
                          styles.categoryPill,
                          {
                            backgroundColor: isActive ? dash.surface : '#A78BFA12',
                            borderColor: isActive ? dash.textMuted : '#A78BFA35',
                            borderWidth: isActive ? 1.5 : 1,
                          },
                        ]}>
                          <View style={[styles.categoryDot, { backgroundColor: '#A78BFA' }]} />
                          <Text style={[
                            styles.categoryPillLabel,
                            { color: isActive ? dash.text : '#A78BFA', fontWeight: isActive ? '700' : '500' }
                          ]}>
                            {label}
                          </Text>
                        </View>
                      </TouchableOpacity>
                    );
                  })}
                </ScrollView>
              </View>
            </View>
          )}

          <View style={styles.countRow}>
            {selectionMode ? (
              <View style={styles.sectionActions}>
                <TouchableOpacity onPress={() => {
                  const fileIds = filtered.map(f => f.id);
                  const allSelected = fileIds.every(id => selectedIds.includes(id));
                  if (allSelected) {
                    setSelectedIds([]);
                  } else {
                    setSelectedIds(fileIds);
                  }
                }} style={styles.textBtn}>
                  <Text style={{ color: dash.accent, fontSize: 13, fontWeight: '700' }}>
                    {filtered.every(f => selectedIds.includes(f.id)) ? 'Deselect All' : 'Select All'}
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={handleRestoreSelected} style={styles.textBtn}>
                  <Text style={{ color: colors.success, fontSize: 13, fontWeight: '700' }}>Restore</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={handleShredSelected} style={styles.textBtnDanger}>
                  <Text style={{ color: colors.error, fontSize: 13, fontWeight: '700' }}>Shred</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={exitSelectionMode} style={styles.cancelBtn}>
                  <Text style={{ color: dash.textMuted, fontSize: 13, fontWeight: '700' }}>Cancel</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <Text style={[styles.countText, { color: dash.textMuted }]}>
                {filtered.length} {filtered.length === 1 ? 'file' : 'files'}
              </Text>
            )}
          </View>

          {filtered.length === 0 && !search && (
            <View style={[styles.emptyCard, { backgroundColor: dash.surface }]}>
              <Text style={{ fontSize: 36, marginBottom: 10 }}>🗑️</Text>
              <Text style={[styles.emptyTitle, { color: dash.text }]}>Trash is empty</Text>
              <Text style={[styles.emptyText, { color: dash.textMuted }]}>Files you delete will appear here.</Text>
            </View>
          )}

          {filtered.length === 0 && search && (
            <View style={[styles.emptyCard, { backgroundColor: dash.surface }]}>
              <Text style={{ fontSize: 38, marginBottom: 10, opacity: 0.3 }}>🔍</Text>
              <Text style={[styles.emptyTitle, { color: dash.text }]}>No results found</Text>
              <Text style={[styles.emptyText, { color: dash.textMuted }]}>Try a different search term</Text>
            </View>
          )}

          {filtered.length > 0 && (
            <FlatList
              data={listData}
              keyExtractor={(item, index) =>
                item.type === 'section' ? `section-${item.label}` : item.file.id
              }
              scrollEnabled={false}
              contentContainerStyle={{ paddingBottom: 140 }}
              renderItem={({ item }) => {
                if (item.type === 'section') {
                  return (
                    <View style={styles.sectionHeaderWrapper}>
                      <Text style={[styles.sectionHeader, { color: dash.textMuted }]}>
                        {item.label}
                      </Text>
                    </View>
                  );
                }

                return (
                  <TrashTile
                    item={item.file}
                    index={0}
                  />
                );
              }}
            />
          )}
        </ScrollView>
      </View>

      <AnimatedTabBar />

      {showFileMenu && targetItem && (
        <Modal transparent animationType="fade" onRequestClose={() => setShowFileMenu(false)}>
          <TouchableOpacity style={modalS.overlay} onPress={() => setShowFileMenu(false)} activeOpacity={1}>
            <View style={[styles.actionSheet, { backgroundColor: dash.surface }]}>
              <View style={[modalS.handle, { backgroundColor: dash.border }]} />
              <Text style={[styles.actionSheetTitle, { color: dash.text }]}>{targetItem.name}</Text>
              {[
                { action: 'restore', label: 'Restore', color: dash.accent },
                { action: 'shred', label: 'Shred Permanently', color: colors.error },
              ].map(item => (
                <TouchableOpacity
                  key={item.action}
                  style={[styles.actionSheetItem, { borderBottomColor: dash.border }]}
                  onPress={() => {
                    setShowFileMenu(false);
                    if (item.action === 'restore') {
                      restoreFileFromTrash(targetItem.id);
                    } else {
                      handleShred(targetItem.id, targetItem.name);
                    }
                  }}
                >
                  <Text style={[styles.actionSheetLabel, { color: item.color }]}>{item.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </TouchableOpacity>
        </Modal>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },

  headerRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    paddingHorizontal: SCREEN_PADDING,
    paddingTop: 8,
    paddingBottom: 16,
  },
  headerTextBlock: { flex: 1, marginRight: 12 },
  headerTitle: { fontSize: 24, fontWeight: '800', letterSpacing: -0.4 },
  headerTagline: { fontSize: 13, fontWeight: '500', marginTop: 4 },
  themeToggle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },

  scrollBody: { paddingHorizontal: SCREEN_PADDING, paddingTop: 8 },

  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 12,
    marginBottom: 10,
  },
  searchInput: { flex: 1, fontSize: 14, fontWeight: '500' },

  filterRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  filterToggleBtn: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  filterToggleText: { fontSize: 13, fontWeight: '600' },
  shredAllText: { fontSize: 12, fontWeight: '700' },

  filterPanel: { marginBottom: 12 },

  categorySection: { paddingVertical: 4, marginBottom: 8 },
  categoryScroll: { paddingHorizontal: 4, gap: 8 },
  categoryPill: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
    gap: 5,
  },
  categoryDot: { width: 6, height: 6, borderRadius: 3 },
  categoryPillLabel: { fontSize: 12 },

  countRow: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    paddingBottom: 8,
  },
  countText: { fontSize: 12, fontWeight: '500' },
  sectionActions: { flexDirection: 'row', gap: 8, alignItems: 'center', flex: 1, justifyContent: 'flex-end' },
  textBtn: { paddingHorizontal: 4, paddingVertical: 4 },
  textBtnDanger: { paddingHorizontal: 4, paddingVertical: 4 },
  cancelBtn: { paddingHorizontal: 4, paddingVertical: 4 },

  sectionHeaderWrapper: { marginTop: 16, marginBottom: 8 },
  sectionHeader: {
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
    opacity: 0.6,
  },

  vaultGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: VAULT_GAP },
  vaultTile: { borderRadius: 20, padding: 14, minHeight: 120, justifyContent: 'space-between' },
  vaultTopRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  vaultIconChip: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center' },
  vaultBottomBlock: { marginTop: 10 },
  vaultName: { fontSize: 14, fontWeight: '700', letterSpacing: -0.2, marginBottom: 4 },
  vaultMetaRow: { flexDirection: 'row', justifyContent: 'space-between' },
  vaultMeta: { fontSize: 11, fontWeight: '600' },
  checkBox: { marginLeft: 4 },
  checkInner: { width: 22, height: 22, borderRadius: 7, borderWidth: 2, alignItems: 'center', justifyContent: 'center' },

  emptyCard: { borderRadius: 20, alignItems: 'center', paddingVertical: 32, paddingHorizontal: 20 },
  emptyTitle: { fontSize: 17, fontWeight: '700', marginBottom: 4 },
  emptyText: { fontSize: 13, textAlign: 'center', marginBottom: 10 },

  actionSheet: { position: 'absolute', bottom: 0, left: 0, right: 0, borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingTop: 8, paddingBottom: 36 },
  actionSheetTitle: { fontSize: 16, fontWeight: '700', paddingHorizontal: 20, paddingVertical: 12, marginBottom: 4 },
  actionSheetItem: { paddingHorizontal: 20, paddingVertical: 15, borderBottomWidth: StyleSheet.hairlineWidth },
  actionSheetLabel: { fontSize: 15, fontWeight: '500' },
});

const modalS = StyleSheet.create({
  overlay: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.6)' },
  handle: { width: 40, height: 4, borderRadius: 2, alignSelf: 'center', marginBottom: 16 },
});