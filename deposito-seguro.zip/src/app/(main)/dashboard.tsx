// File: src/app/(main)/dashboard.tsx
import { router } from 'expo-router';
import {
  Box,
  Cloud,
  FileText,
  Folder,
  Image as ImageIcon,
  MoreVertical,
  Music,
  Plus,
  Search,
  Smartphone,
  Video,
} from 'lucide-react-native';
import { useEffect, useRef, useState } from 'react';
import {
  Alert,
  Dimensions,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import Animated, {
  FadeInDown,
  useAnimatedScrollHandler,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from 'react-native-reanimated';
import AnimatedTabBar from '../../components/AnimatedTabBar';
import { EncryptionKeyPicker } from '../../components/EncryptionKeyPicker';
import { VaultHeader } from '../../components/VaultHeader';
import { useTheme } from '../../contexts/ThemeContext'; // Named import
import { useSettingsStore } from '../../store/settingsStore';
import { useVaultStore } from '../../store/vaultStore';
import { promptCreateEncryptionKey } from '../../utils/encryptionKeyPrompt';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const SCREEN_PADDING = 24;
const CATEGORY_GAP = 12;
const VAULT_GAP = 16;
const CATEGORY_TILE_WIDTH = (SCREEN_WIDTH - SCREEN_PADDING * 2 - CATEGORY_GAP * 2) / 3;
const VAULT_TILE_WIDTH = (SCREEN_WIDTH - SCREEN_PADDING * 2 - VAULT_GAP) / 2;

const DISPLAY_CAPACITY_GB = 100;

export default function DashboardScreen() {
  const { colors, isDark } = useTheme();
  const {
    folders, files,
    createFolder, hydrateVault, renameFolder, moveFolder,
    deleteFolder, shredFolder,
    shredMultipleFolders, exportFolderFiles, toggleFavorite,
    assignFolderEncryptionKey,
  } = useVaultStore();
  const { encryptionKeys, createEncryptionKey, encryptionKeyExists } = useSettingsStore();

  const [showFolderModal, setShowFolderModal] = useState(false);
  const [folderName, setFolderName] = useState('');
  const [showFolderMenu, setShowFolderMenu] = useState(false);
  const [targetFolder, setTargetFolder] = useState<any>(null);
  const [showRenameModal, setShowRenameModal] = useState(false);
  const [renameText, setRenameText] = useState('');
  const [showMoveModal, setShowMoveModal] = useState(false);
  const [selectionMode, setSelectionMode] = useState(false);
  const [selectedFolderIds, setSelectedFolderIds] = useState<string[]>([]);
  const [keyPickerTarget, setKeyPickerTarget] = useState<{ id: string; name: string } | null>(null);

  const scrollY = useSharedValue(0);
  const scrollViewRef = useRef<ScrollView>(null);

  const onScroll = useAnimatedScrollHandler({
    onScroll: (event) => {
      scrollY.value = event.contentOffset.y;
    },
  });

  useEffect(() => { hydrateVault(); }, [hydrateVault]);

  const activeFiles = files.filter(f => !f.isTrash);
  const totalBytes = activeFiles.reduce((sum, f) => sum + f.size, 0);
  const totalGB = totalBytes / (1024 * 1024 * 1024);
  const totalMB = (totalBytes / (1024 * 1024)).toFixed(1);
  const displayStorageLabel = totalGB >= 1 ? `${totalGB.toFixed(1)} GB` : `${totalMB} MB`;
  const percentUsed = Math.min(100, Math.round((totalGB / DISPLAY_CAPACITY_GB) * 100));

  const imageCount = activeFiles.filter(f => f.mimeType?.startsWith('image/')).length;
  const videoCount = activeFiles.filter(f => f.mimeType?.startsWith('video/')).length;
  const audioCount = activeFiles.filter(f => f.mimeType?.startsWith('audio/')).length;
  const appCount = activeFiles.filter(f =>
    f.mimeType === 'application/vnd.android.package-archive' ||
    f.mimeType === 'application/x-msdownload' ||
    f.name?.endsWith('.apk') || f.name?.endsWith('.exe') || f.name?.endsWith('.dmg')
  ).length;
  const docCount = activeFiles.filter(f =>
    !f.mimeType?.startsWith('image/') &&
    !f.mimeType?.startsWith('video/') &&
    !f.mimeType?.startsWith('audio/') &&
    !f.name?.endsWith('.apk') && !f.name?.endsWith('.exe') && !f.name?.endsWith('.dmg') &&
    (f.mimeType?.includes('pdf') || f.mimeType?.includes('document') || f.mimeType?.includes('text') || f.mimeType?.includes('sheet'))
  ).length;
  const otherCount = activeFiles.length - imageCount - videoCount - audioCount - appCount - docCount;

  // FIXED: Standard vibrant fallbacks since colors.category doesn't exist
  const categoryData = [
    { key: 'images', label: 'Images', count: imageCount, color: colors.primary || '#6366F1', Icon: ImageIcon },
    { key: 'videos', label: 'Videos', count: videoCount, color: '#3B82F6', Icon: Video },
    { key: 'docs', label: 'Docs', count: docCount, color: '#10B981', Icon: FileText },
    { key: 'audio', label: 'Audio', count: audioCount, color: '#8B5CF6', Icon: Music },
    { key: 'apps', label: 'Apps', count: appCount, color: '#F59E0B', Icon: Smartphone },
    { key: 'other', label: 'Other', count: otherCount, color: '#6B7280', Icon: Box },
  ];

  const vaultAccentPalette = ['#A78BFA', '#60A5FA', '#34D399', '#FB7185', '#FBBF24', '#F472B6'];

  const rootFolders = folders.filter(f => !f.parentId);
  const subFolders = folders.filter(f => !!f.parentId);
  const allFoldersOrdered = [...rootFolders, ...subFolders];

  const handleDirectoryProvisioning = () => {
    if (Platform.OS === 'web') {
      const name = window.prompt('Folder name:');
      if (name && name.trim()) createFolder(name.trim(), colors.primary, 'folder', false);
    } else {
      setShowFolderModal(true);
    }
  };

  const confirmFolderCreation = () => {
    if (folderName.trim()) createFolder(folderName.trim(), colors.primary, 'folder', false);
    setShowFolderModal(false);
    setFolderName('');
  };

  const handleRegisterEncryptionKey = (folderId: string, folderNameValue: string) => {
    if (encryptionKeys.length >= 20) {
      Alert.alert('Encryption Key Limit', 'You can only create up to 20 encryption keys.');
      return;
    }

    promptCreateEncryptionKey(folderNameValue, async (options) => {
      if (encryptionKeys.length >= 20) {
        Alert.alert('Encryption Key Limit', 'You can only create up to 20 encryption keys.');
        return;
      }

      if (encryptionKeyExists(options.name)) {
        Alert.alert('Key Name Already Used', 'Encryption key names must be unique.');
        return;
      }

      const key = await createEncryptionKey(options.name, options.customKey, options.description);
      if (!key) {
        Alert.alert('Encryption Key Limit', 'You can only create up to 20 encryption keys.');
        return;
      }

      await assignFolderEncryptionKey(folderId, key.id);
      Alert.alert('Encryption Registered', 'A new encryption key was generated and assigned.');
    });
  };

  const handleFolderAction = (folder: any, action: string) => {
    setShowFolderMenu(false);
    switch (action) {
      case 'rename':
        setTargetFolder(folder); setRenameText(folder.name); setShowRenameModal(true); break;
      case 'move':
        setTargetFolder(folder); setShowMoveModal(true); break;
      case 'export':
        exportFolderFiles(folder.id).then(paths => {
          if (paths.length > 0) Alert.alert('Export Complete', `Exported ${paths.length} files`);
          else Alert.alert('Nothing to Export', 'This vault has no files to export.');
        }).catch(() => Alert.alert('Export Failed', 'Something went wrong while exporting.'));
        break;
      case 'delete':
        deleteFolder(folder.id); break;
      case 'shred':
        Alert.alert('Delete Permanently', 'Shred this folder and all contents?',
          [{ text: 'Cancel', style: 'cancel' }, { text: 'Shred', style: 'destructive', onPress: () => shredFolder(folder.id) }]); break;
      case 'register-key':
        handleRegisterEncryptionKey(folder.id, folder.name); break;
      case 'assign-key':
        if (encryptionKeys.length === 0) {
          Alert.alert('No Encryption Keys', 'Create an encryption key in Settings first.');
        } else {
          setKeyPickerTarget({ id: folder.id, name: folder.name });
        }
        break;
      case 'favorite':
        toggleFavorite && toggleFavorite(folder.id);
        break;
    }
  };

  const confirmRename = () => {
    if (targetFolder) renameFolder(targetFolder.id, renameText.trim());
    setShowRenameModal(false);
  };

  const confirmMove = (targetParentId: string) => {
    if (targetFolder) moveFolder(targetFolder.id, targetParentId);
    setShowMoveModal(false);
  };

  const toggleFolderSelection = (folderId: string) => {
    setSelectedFolderIds(prev => prev.includes(folderId) ? prev.filter(id => id !== folderId) : [...prev, folderId]);
  };

  const handleSelectAllFolders = () => {
    const allIds = folders.map(f => f.id);
    setSelectedFolderIds(selectedFolderIds.length === allIds.length ? [] : allIds);
  };

  const handleBulkShredFolders = () => {
    if (selectedFolderIds.length === 0) return;
    Alert.alert('Delete Permanently', `Shred ${selectedFolderIds.length} folders?`,
      [{ text: 'Cancel', style: 'cancel' }, { text: 'Shred', style: 'destructive', onPress: () => shredMultipleFolders(selectedFolderIds) }]);
  };

  const exitSelectionMode = () => { setSelectionMode(false); setSelectedFolderIds([]); };

  const moveDestinations = folders.filter(f => f.id !== targetFolder?.id);

  const PressScale = ({
    children, onPress, onLongPress, style,
  }: { children: React.ReactNode; onPress?: () => void; onLongPress?: () => void; style?: any }) => {
    const scale = useSharedValue(1);
    const animatedStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
    return (
      <Pressable
        onPress={onPress}
        onLongPress={onLongPress}
        onPressIn={() => { scale.value = withTiming(0.95, { duration: 100 }); }}
        onPressOut={() => { scale.value = withTiming(1, { duration: 150 }); }}
      >
        <Animated.View style={[style, animatedStyle]}>{children}</Animated.View>
      </Pressable>
    );
  };

  const CategoryTile = ({ item, index }: { item: typeof categoryData[number]; index: number }) => (
    <Animated.View entering={FadeInDown.delay(80 + index * 30).duration(300)}>
      <PressScale
        onPress={() => router.push('/(main)/search')}
        style={[styles.categoryTile, { backgroundColor: colors.surface, width: CATEGORY_TILE_WIDTH }]}
      >
        <View style={[styles.categoryIconChip, { backgroundColor: `${item.color}1A` }]}>
          <item.Icon size={20} color={item.color} strokeWidth={2.2} />
        </View>
        <Text style={[styles.categoryLabel, { color: colors.text }]} numberOfLines={1}>{item.label}</Text>
        <Text style={[styles.categoryCount, { color: colors.textMuted }]}>{item.count} files</Text>
      </PressScale>
    </Animated.View>
  );

  const VaultTile = ({ item, index }: { item: any; index: number }) => {
    const folderFileCount = files.filter(f => f.folderId === item.id && !f.isTrash).length;
    const folderMB = (
      files.filter(f => f.folderId === item.id && !f.isTrash).reduce((sum, f) => sum + f.size, 0) / (1024 * 1024)
    );
    const sizeLabel = folderMB >= 1024 ? `${(folderMB / 1024).toFixed(1)} GB` : `${folderMB.toFixed(0)} MB`;
    const isSelected = selectedFolderIds.includes(item.id);
    const accentColor = vaultAccentPalette[index % vaultAccentPalette.length];

    return (
      <Animated.View entering={FadeInDown.delay(220 + index * 50).duration(300)}>
        <PressScale
          onLongPress={() => { setSelectionMode(true); setSelectedFolderIds([item.id]); }}
          onPress={() => {
            if (selectionMode) toggleFolderSelection(item.id);
            else router.push({ pathname: '/(main)/folder/[id]', params: { id: item.id } });
          }}
          style={[
            styles.vaultTile,
            {
              backgroundColor: colors.surface,
              width: VAULT_TILE_WIDTH,
              borderColor: colors.accent,
              borderWidth: isSelected ? 2 : 0,
            },
          ]}
        >
          <View style={styles.vaultTopRow}>
            <View style={[styles.vaultIconChip, { backgroundColor: `${accentColor}26` }]}>
              <Folder size={20} color={accentColor} strokeWidth={2.2} />
            </View>
            {selectionMode ? (
              <View style={styles.checkBox}>
                {/* FIXED: Replaced colors.fabText fallback to white */}
                <View style={[styles.checkInner, { backgroundColor: isSelected ? colors.accent : 'transparent', borderColor: colors.accent }]}>
                  {isSelected && <Text style={{ color: '#FFFFFF', fontSize: 10, fontWeight: '700' }}>✓</Text>}
                </View>
              </View>
            ) : (
              <TouchableOpacity
                onPress={() => { setTargetFolder(item); setShowFolderMenu(true); }}
                hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
              >
                <MoreVertical size={18} color={colors.textMuted} />
              </TouchableOpacity>
            )}
          </View>

          <View style={styles.vaultBottomBlock}>
            <Text style={[styles.vaultName, { color: colors.text }]} numberOfLines={1}>
              {item.name}
              {item.isEncrypted && item.encryptionKeyId ? ' 🔒' : ''}
            </Text>
            <View style={styles.vaultMetaRow}>
              <Text style={[styles.vaultMeta, { color: colors.textMuted }]}>{folderFileCount} files</Text>
              <Text style={[styles.vaultMeta, { color: colors.textMuted }]}>{sizeLabel}</Text>
            </View>
          </View>
        </PressScale>
      </Animated.View>
    );
  };

  return (
    // FIXED: Changed colors.bg to colors.background
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <VaultHeader title="Deposito Seguro" scrollY={scrollY} />

      <Animated.ScrollView
        ref={scrollViewRef}
        onScroll={onScroll}
        scrollEventThrottle={16}
        contentContainerStyle={styles.scrollBody}
        showsVerticalScrollIndicator={false}
      >
        <Pressable onPress={() => router.push('/(main)/search')}>
          <View style={[styles.searchBar, { backgroundColor: colors.surface }]}>
            <Search size={18} color={colors.textMuted} />
            <Text style={[styles.searchPlaceholder, { color: colors.textMuted }]}>Search files, vaults...</Text>
          </View>
        </Pressable>

        {/* Storage summary card */}
        <View
          style={[
            styles.storageCard,
            { backgroundColor: isDark ? colors.surface : colors.accent },
          ]}
        >
          <View style={styles.storageTopRow}>
            <View style={styles.storageLabelRow}>
              <Cloud size={18} color={isDark ? colors.textMuted : colors.text} />
              <Text style={[styles.storageLabel, { color: isDark ? colors.textMuted : colors.text }]}>
                Cloud Storage
              </Text>
            </View>
            {/* FIXED: Changed colors.surfaceHover to colors.surfaceElevated */}
            <View style={[styles.usedPill, { backgroundColor: isDark ? colors.surfaceElevated : colors.surface }]}>
              <Text style={[styles.usedPillText, { color: colors.text }]}>{percentUsed}% Used</Text>
            </View>
          </View>

          <View style={styles.storageValueRow}>
            <Text style={[styles.storageValue, { color: colors.text }]}>{displayStorageLabel.split(' ')[0]}</Text>
            <Text style={[styles.storageUnit, { color: colors.text }]}> {displayStorageLabel.split(' ')[1]}</Text>
          </View>

          {/* FIXED: Changed colors.surfaceHover to colors.surfaceElevated, and colors.fabBg to colors.primary */}
          <View style={[styles.progressTrack, { backgroundColor: isDark ? colors.surfaceElevated : 'rgba(255,255,255,0.4)' }]}>
            <View
              style={[
                styles.progressFill,
                { backgroundColor: isDark ? colors.primary : colors.text, width: `${Math.max(2, percentUsed)}%` },
              ]}
            />
          </View>
          <View style={styles.progressLabelsRow}>
            <Text style={[styles.progressLabel, { color: isDark ? colors.textMuted : colors.text }]}>0 GB</Text>
            <Text style={[styles.progressLabel, { color: isDark ? colors.textMuted : colors.text }]}>
              {DISPLAY_CAPACITY_GB} GB
            </Text>
          </View>
        </View>

        {/* Categories */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>Categories</Text>
            <TouchableOpacity onPress={() => router.push('/(main)/search')}>
              <Text style={[styles.seeAll, { color: colors.textMuted }]}>See all</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.categoryGrid}>
            {categoryData.map((item, i) => (
              <CategoryTile key={item.key} item={item} index={i} />
            ))}
          </View>
        </View>

        {/* My Vaults */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>My Vaults</Text>
            {selectionMode ? (
              <View style={styles.sectionActions}>
                <TouchableOpacity onPress={handleSelectAllFolders} style={styles.textBtn}>
                  <Text style={{ color: colors.accent, fontSize: 13, fontWeight: '700' }}>
                    {selectedFolderIds.length === folders.length ? 'Deselect All' : 'Select All'}
                  </Text>
                </TouchableOpacity>
                {selectedFolderIds.length > 0 && (
                  <TouchableOpacity onPress={handleBulkShredFolders} style={styles.textBtnDanger}>
                    <Text style={{ color: colors.error, fontSize: 13, fontWeight: '700' }}>Shred</Text>
                  </TouchableOpacity>
                )}
                <TouchableOpacity onPress={exitSelectionMode} style={styles.cancelBtn}>
                  <Text style={{ color: colors.textMuted, fontSize: 13, fontWeight: '700' }}>Cancel</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <TouchableOpacity onPress={() => router.push('/(main)/folders')}>
                <Text style={[styles.seeAll, { color: colors.textMuted }]}>See all</Text>
              </TouchableOpacity>
            )}
          </View>

          {folders.length === 0 ? (
            <View style={[styles.emptyCard, { backgroundColor: colors.surface }]}>
              <Text style={{ fontSize: 48, marginBottom: 12 }}>🏦</Text>
              <Text style={[styles.emptyTitle, { color: colors.text }]}>No Vaults Yet</Text>
              <Text style={[styles.emptyText, { color: colors.textMuted }]}>Create your first secure vault to get started</Text>
              {/* FIXED: Changed colors.fabBg to colors.primary, and colors.fabText to #FFFFFF */}
              <TouchableOpacity onPress={handleDirectoryProvisioning} style={[styles.emptyBtn, { backgroundColor: colors.primary }]}>
                <Text style={{ color: '#FFFFFF', fontWeight: '700', fontSize: 14 }}>Create First Vault</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <View style={styles.vaultGrid}>
              {allFoldersOrdered.map((item, index) => (
                <VaultTile key={item.id} item={item} index={index} />
              ))}
            </View>
          )}
        </View>

        <View style={{ height: 140 }} />
      </Animated.ScrollView>

      {/* Floating Action Button */}
      {/* FIXED: Changed colors.fabBg to colors.primary, and colors.fabText to #FFFFFF */}
      <TouchableOpacity
        onPress={handleDirectoryProvisioning}
        activeOpacity={0.85}
        style={[styles.fab, { backgroundColor: colors.primary }]}
        accessibilityRole="button"
        accessibilityLabel="Create new vault"
      >
        <Plus size={26} color="#FFFFFF" strokeWidth={2.4} />
      </TouchableOpacity>

      <AnimatedTabBar />

      {/* ── Modals ── */}
      <Modal visible={showFolderModal} transparent animationType="fade" onRequestClose={() => setShowFolderModal(false)}>
        <View style={modalS.overlay}>
          {/* FIXED: Changed colors.bg to colors.background */}
          <Animated.View entering={FadeInDown.duration(300)} style={[modalS.sheet, { backgroundColor: colors.surface }]}>
            <View style={[modalS.handle, { backgroundColor: colors.border }]} />
            <Text style={[modalS.title, { color: colors.text }]}>New Vault</Text>
            <TextInput
              style={[modalS.input, { borderColor: colors.border, color: colors.text, backgroundColor: colors.background }]}
              placeholder="Vault name"
              placeholderTextColor={colors.textMuted}
              value={folderName}
              onChangeText={setFolderName}
              autoFocus
            />
            <View style={modalS.btnRow}>
              <TouchableOpacity onPress={() => setShowFolderModal(false)} style={[modalS.btn, { borderColor: colors.border, borderWidth: 1 }]}>
                <Text style={{ color: colors.text, fontWeight: '700' }}>Cancel</Text>
              </TouchableOpacity>
              {/* FIXED: Changed colors.fabBg to colors.primary, and colors.fabText to #FFFFFF */}
              <TouchableOpacity onPress={confirmFolderCreation} style={[modalS.btn, { backgroundColor: colors.primary }]}>
                <Text style={{ color: '#FFFFFF', fontWeight: '700' }}>Create</Text>
              </TouchableOpacity>
            </View>
          </Animated.View>
        </View>
      </Modal>

      {showFolderMenu && targetFolder && (
        <Modal transparent animationType="fade" onRequestClose={() => setShowFolderMenu(false)}>
          <TouchableOpacity style={modalS.overlay} onPress={() => setShowFolderMenu(false)} activeOpacity={1}>
            <Animated.View entering={FadeInDown.duration(300)} style={[styles.actionSheet, { backgroundColor: colors.surface }]}>
              <View style={[modalS.handle, { backgroundColor: colors.border }]} />
              <Text style={[styles.actionSheetTitle, { color: colors.text }]}>{targetFolder.name}</Text>
              {[
                { action: 'rename', label: 'Rename', color: colors.text },
                { action: 'move', label: 'Move', color: colors.text },
                { action: 'export', label: 'Export', color: colors.text },
                { action: 'register-key', label: 'Create & Assign Key', color: colors.accent },
                { action: 'assign-key', label: 'Assign Existing Key', color: colors.accent },
                { action: 'favorite', label: targetFolder.isFavorite ? 'Remove from Favorites' : 'Add to Favorites', color: '#FBBF24' },
                { action: 'delete', label: 'Move to Trash', color: colors.error },
                { action: 'shred', label: 'Shred Permanently', color: colors.error },
              ].map(item => (
                <TouchableOpacity key={item.action} style={[styles.actionSheetItem, { borderBottomColor: colors.border }]} onPress={() => handleFolderAction(targetFolder, item.action)}>
                  <Text style={[styles.actionSheetLabel, { color: item.color }]}>{item.label}</Text>
                </TouchableOpacity>
              ))}
            </Animated.View>
          </TouchableOpacity>
        </Modal>
      )}

      <EncryptionKeyPicker
        visible={!!keyPickerTarget}
        onClose={() => setKeyPickerTarget(null)}
        onSelectKey={async (keyId) => {
          if (!keyPickerTarget) return;
          await assignFolderEncryptionKey(keyPickerTarget.id, keyId);
          setKeyPickerTarget(null);
          Alert.alert('Encryption Assigned', 'The selected encryption key is now registered.');
        }}
      />

      {showRenameModal && (
        <Modal transparent animationType="fade">
          <View style={modalS.overlay}>
            {/* FIXED: Changed colors.bg to colors.background */}
            <Animated.View entering={FadeInDown.duration(300)} style={[modalS.sheet, { backgroundColor: colors.surface }]}>
              <View style={[modalS.handle, { backgroundColor: colors.border }]} />
              <Text style={[modalS.title, { color: colors.text }]}>Rename Vault</Text>
              <TextInput
                style={[modalS.input, { borderColor: colors.border, color: colors.text, backgroundColor: colors.background }]}
                value={renameText}
                onChangeText={setRenameText}
                autoFocus
              />
              <View style={modalS.btnRow}>
                <TouchableOpacity onPress={() => setShowRenameModal(false)} style={[modalS.btn, { borderColor: colors.border, borderWidth: 1 }]}>
                  <Text style={{ color: colors.text, fontWeight: '700' }}>Cancel</Text>
                </TouchableOpacity>
                {/* FIXED: Changed colors.fabBg to colors.primary, and colors.fabText to #FFFFFF */}
                <TouchableOpacity onPress={confirmRename} style={[modalS.btn, { backgroundColor: colors.primary }]}>
                  <Text style={{ color: '#FFFFFF', fontWeight: '700' }}>Save</Text>
                </TouchableOpacity>
              </View>
            </Animated.View>
          </View>
        </Modal>
      )}

      {showMoveModal && (
        <Modal transparent animationType="fade">
          <View style={modalS.overlay}>
            <Animated.View entering={FadeInDown.duration(300)} style={[modalS.sheet, { backgroundColor: colors.surface }]}>
              <View style={[modalS.handle, { backgroundColor: colors.border }]} />
              <Text style={[modalS.title, { color: colors.text }]}>Move Vault</Text>
              {moveDestinations.length === 0 ? (
                <Text style={[styles.emptyText, { color: colors.textMuted, paddingVertical: 12 }]}>
                  No other vaults available to move into.
                </Text>
              ) : (
                moveDestinations.map(f => (
                  <TouchableOpacity key={f.id} style={[styles.actionSheetItem, { borderBottomColor: colors.border }]} onPress={() => confirmMove(f.id)}>
                    <Text style={[styles.actionSheetLabel, { color: colors.text }]}>📁  {f.name}</Text>
                  </TouchableOpacity>
                ))
              )}
            </Animated.View>
          </View>
        </Modal>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  scrollBody: { paddingHorizontal: SCREEN_PADDING, paddingTop: 8, paddingBottom: 140 },

  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 14,
    marginBottom: 32,
  },
  searchPlaceholder: { fontSize: 14, fontWeight: '500' },

  storageCard: { borderRadius: 24, padding: 24, marginBottom: 32 },
  storageTopRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
  storageLabelRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  storageLabel: { fontSize: 13, fontWeight: '600' },
  usedPill: { borderRadius: 999, paddingHorizontal: 12, paddingVertical: 6 },
  usedPillText: { fontSize: 12, fontWeight: '700' },
  storageValueRow: { flexDirection: 'row', alignItems: 'baseline', marginBottom: 18 },
  storageValue: { fontSize: 30, fontWeight: '800', letterSpacing: -0.5 },
  storageUnit: { fontSize: 16, fontWeight: '700' },
  progressTrack: { height: 5, borderRadius: 3, overflow: 'hidden', marginBottom: 8 },
  progressFill: { height: '100%', borderRadius: 3 },
  progressLabelsRow: { flexDirection: 'row', justifyContent: 'space-between' },
  progressLabel: { fontSize: 12, fontWeight: '500' },

  section: { marginBottom: 32 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
  sectionTitle: { fontSize: 18, fontWeight: '700', letterSpacing: -0.3 },
  seeAll: { fontSize: 13, fontWeight: '600' },
  sectionActions: { flexDirection: 'row', gap: 10, alignItems: 'center' },
  textBtn: { paddingHorizontal: 4, paddingVertical: 4 },
  textBtnDanger: { paddingHorizontal: 4, paddingVertical: 4 },
  cancelBtn: { paddingHorizontal: 4, paddingVertical: 4 },

  categoryGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: CATEGORY_GAP },
  categoryTile: { borderRadius: 16, paddingVertical: 18, paddingHorizontal: 10, alignItems: 'center' },
  categoryIconChip: { width: 44, height: 44, borderRadius: 13, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  categoryLabel: { fontSize: 13, fontWeight: '700', marginBottom: 3 },
  categoryCount: { fontSize: 11, fontWeight: '600' },

  vaultGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: VAULT_GAP },
  vaultTile: { borderRadius: 24, padding: 18, minHeight: 150, justifyContent: 'space-between' },
  vaultTopRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  vaultIconChip: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  vaultBottomBlock: { marginTop: 14 },
  vaultName: { fontSize: 15, fontWeight: '700', letterSpacing: -0.2, marginBottom: 6 },
  vaultMetaRow: { flexDirection: 'row', justifyContent: 'space-between' },
  vaultMeta: { fontSize: 12, fontWeight: '600' },
  checkBox: { marginLeft: 4 },
  checkInner: { width: 22, height: 22, borderRadius: 7, borderWidth: 2, alignItems: 'center', justifyContent: 'center' },

  emptyCard: { borderRadius: 24, alignItems: 'center', paddingVertical: 40, paddingHorizontal: 24 },
  emptyTitle: { fontSize: 18, fontWeight: '700', marginBottom: 4 },
  emptyText: { fontSize: 14, textAlign: 'center', marginBottom: 12 },
  emptyBtn: { paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12, marginTop: 8 },

  fab: {
    position: 'absolute',
    right: SCREEN_PADDING,
    bottom: 100,
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 6,
  },

  actionSheet: { position: 'absolute', bottom: 0, left: 0, right: 0, borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingTop: 8, paddingBottom: 36 },
  actionSheetTitle: { fontSize: 16, fontWeight: '700', paddingHorizontal: 20, paddingVertical: 12, marginBottom: 4 },
  actionSheetItem: { paddingHorizontal: 20, paddingVertical: 15, borderBottomWidth: StyleSheet.hairlineWidth },
  actionSheetLabel: { fontSize: 15, fontWeight: '500' },
});

const modalS = StyleSheet.create({
  overlay: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.6)' },
  handle: { width: 40, height: 4, borderRadius: 2, alignSelf: 'center', marginBottom: 16 },
  sheet: { borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, paddingBottom: 32 },
  title: { fontSize: 20, fontWeight: '700', marginBottom: 16, letterSpacing: -0.3 },
  input: { borderWidth: 1, borderRadius: 14, paddingHorizontal: 16, paddingVertical: 14, marginBottom: 16, fontSize: 15 },
  btnRow: { flexDirection: 'row', gap: 12 },
  btn: { flex: 1, paddingVertical: 14, borderRadius: 12, alignItems: 'center' },
});